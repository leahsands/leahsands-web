<div class="row">
	<div class="twelve columns">
    	<footer class="footer" role="contentinfo">
        	<div id="inner-footer" class="wrap clearfix">
        		<p class="source-org copyright">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?></p>
        	</div> <!-- end #inner-footer -->
      	</footer> <!-- end footer -->
    </div>
</div>

</div> <!-- end #container -->
	<?php wp_footer(); ?>
</body>
</html> <!-- end page. what a ride! -->