About GumbyPress
===============
A Gumby Framework WordPress Starter Theme


Getting Started
-----------------

This theme is to serve as a starter theme when working on a new WordPress theme.
All the necessary Gumby framework files have been included.
The dropdown menu works as well.
To test it out, just download and install it.
Create a nice theme out of this.
Thanks.


Contribute
-----------------

Contributions are welcome. Kinldy fork the repo and submit a pull request.
Thanks.


Developed By
-----------------

http://twitter.com/tubiz


For Bugs, Fixes, Issues, Feature Request
-----------------

https://github.com/tubiz/GumbyPress/issues


Credits
-----------------

- https://github.com/Automattic/_s for some WordPress functions
- https://github.com/eddiemachado for some html snippets
- https://github.com/GumbyFramework/Gumby for the excellent framework

